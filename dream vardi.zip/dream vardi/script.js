﻿let currentRole = "";
let questions = JSON.parse(localStorage.getItem("mcqQuestions")) || [];
let currentQuestion = 0;
let score = 0;
let correct = 0;
let wrong = 0;
let startTime, timer;
let userAnswers = [];
let timeTakenPerQuestion = [];

function showLogin(role) {
  currentRole = role;
  document.getElementById("home-screen").classList.add("hidden");
  document.getElementById("login-screen").classList.remove("hidden");
  document.getElementById("login-title").textContent =
    role === "admin" ? "एडमिन लॉगिन" : "स्टूडेंट लॉगिन";
  document.getElementById("password").value = "";
}

function goHome() {
  document.querySelectorAll(".container").forEach((el) => el.classList.add("hidden"));
  document.getElementById("home-screen").classList.remove("hidden");
  resetState();
}

function resetState() {
  currentRole = "";
  currentQuestion = 0;
  score = 0;
  correct = 0;
  wrong = 0;
  clearInterval(timer);
  userAnswers = [];
  timeTakenPerQuestion = [];

  document.getElementById("question-box").innerHTML = "";
  document.getElementById("answer-details").innerHTML = "";
  document.getElementById("quiz-section").classList.add("hidden");
  document.getElementById("result-screen").classList.add("hidden");

  document.getElementById("welcome-student").classList.remove("hidden");
  document.getElementById("student-heading").classList.remove("hidden");
}

function login() {
  const password = document.getElementById("password").value;
  if (currentRole === "admin" && password === "705556") {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("admin-screen").classList.remove("hidden");
    showAdminQuestions();
    document.getElementById("exam-heading").value = localStorage.getItem("quizHeading") || "";
  } else if (currentRole === "student" && password === "445691") {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("student-screen").classList.remove("hidden");
    questions = JSON.parse(localStorage.getItem("mcqQuestions")) || [];
    const heading = localStorage.getItem("quizHeading") || "MCQ टेस्ट";
    document.getElementById("student-heading").innerHTML =
      `<button class="start-btn" onclick="startConfirmation()">📘 ${heading} - टेस्ट शुरू करें</button>`;
  } else {
    alert("गलत पासवर्ड");
  }
}

function addQuestion() {
  const heading = document.getElementById("exam-heading").value.trim();
  const q = document.getElementById("question").value.trim();
  const opt1 = document.getElementById("opt1").value.trim();
  const opt2 = document.getElementById("opt2").value.trim();
  const opt3 = document.getElementById("opt3").value.trim();
  const opt4 = document.getElementById("opt4").value.trim();
  const correct = document.getElementById("correct").value.trim();
  const explanation = document.getElementById("explanation").value;
  const time = parseInt(document.getElementById("time").value);

  if (!q || !opt1 || !opt2 || !opt3 || !opt4 || !correct || isNaN(time)) {
    return alert("कृपया सभी फ़ील्ड भरें");
  }

  if (![opt1, opt2, opt3, opt4].includes(correct)) {
    return alert("सही उत्तर चारों विकल्पों में से एक होना चाहिए");
  }

  localStorage.setItem("quizHeading", heading);
  questions.push({ q, options: [opt1, opt2, opt3, opt4], answer: correct, explanation, time });
  localStorage.setItem("mcqQuestions", JSON.stringify(questions));
  showAdminQuestions();
  clearInputs();
}

function clearInputs() {
  ["question", "opt1", "opt2", "opt3", "opt4", "correct", "explanation", "time"].forEach(id => {
    document.getElementById(id).value = "";
  });
  document.getElementById("question").focus();
}

function showAdminQuestions() {
  const list = document.getElementById("admin-question-list");
  list.innerHTML = questions.map((q, i) => `
    <div>
      <b>प्रश्न ${i + 1}:</b> ${q.q}<br>
      <button onclick="editQuestion(${i})">✏️</button>
      <button onclick="deleteQuestion(${i})">🗑️</button>
    </div>
  `).join('');
}

function editQuestion(i) {
  const q = questions[i];
  document.getElementById("question").value = q.q;
  document.getElementById("opt1").value = q.options[0];
  document.getElementById("opt2").value = q.options[1];
  document.getElementById("opt3").value = q.options[2];
  document.getElementById("opt4").value = q.options[3];
  document.getElementById("correct").value = q.answer;
  document.getElementById("explanation").value = q.explanation;
  document.getElementById("time").value = q.time || 75;
  questions.splice(i, 1);
  localStorage.setItem("mcqQuestions", JSON.stringify(questions));
  showAdminQuestions();
}

function deleteQuestion(i) {
  if (confirm("क्या आप वाकई इस प्रश्न को हटाना चाहते हैं?")) {
    questions.splice(i, 1);
    localStorage.setItem("mcqQuestions", JSON.stringify(questions));
    showAdminQuestions();
  }
}

function startConfirmation() {
  if (questions.length === 0) return alert("कोई प्रश्न उपलब्ध नहीं है।");
  const totalTime = questions.reduce((sum, q) => sum + (q.time || 75), 0);
  if (confirm(`कुल प्रश्न: ${questions.length}\nकुल समय: ${Math.floor(totalTime/60)} मिनट\nक्या आप परीक्षा शुरू करना चाहते हैं?`)) {
    document.getElementById("welcome-student").classList.add("hidden");
    document.getElementById("student-heading").classList.add("hidden"); // ✅ Hide start quiz heading
    document.getElementById("quiz-section").classList.remove("hidden");

    const quizHeading = localStorage.getItem("quizHeading") || "परीक्षा";
    document.getElementById("quiz-title").textContent = `✍️ ${quizHeading} - प्रश्नोत्तरी प्रारंभ`;

    showQuestion();
  }
}

function showQuestion() {
  if (currentQuestion >= questions.length) return;
  const q = questions[currentQuestion];
  document.getElementById("question-box").innerHTML = `
    <div class="question-box">
      <div class="question"><b>प्रश्न ${currentQuestion + 1}:</b> ${q.q}</div>
      <div class="options">
        ${q.options.map((opt, i) => `
          <label><input type="radio" name="option" value="${opt}"> ${opt}</label>
        `).join('')}
      </div>
    </div>
  `;
  startTime = new Date();
  clearInterval(timer);
  startCountdown(q.time || 75);
}

function startCountdown(seconds) {
  let timeLeft = seconds;
  timer = setInterval(() => {
    const min = Math.floor(timeLeft / 60);
    const sec = timeLeft % 60;
    document.getElementById("timer").textContent = `समय: ${min}:${sec < 10 ? '0' + sec : sec}`;
    if (--timeLeft < 0) {
      clearInterval(timer);
      saveAndNext();
    }
  }, 1000);
}

function saveAndNext() {
  const selected = document.querySelector('input[name="option"]:checked');
  const timeSpent = Math.round((new Date() - startTime) / 1000);
  timeTakenPerQuestion.push(timeSpent);
  const userAns = selected ? selected.value : null;
  userAnswers.push(userAns);

  if (userAns === questions[currentQuestion].answer) {
    score++;
    correct++;
  } else {
    wrong++;
  }

  currentQuestion++;
  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    finalSubmit();
  }
}

function finalSubmit() {
  if (!confirm("क्या आप वाकई अंतिम सबमिट करना चाहते हैं?")) return;
  clearInterval(timer);
  document.getElementById("student-screen").classList.add("hidden");
  document.getElementById("result-screen").classList.remove("hidden");
  document.getElementById("total-q").textContent = questions.length;
  document.getElementById("correct-q").textContent = correct;
  document.getElementById("wrong-q").textContent = wrong;
  document.getElementById("score").textContent = score;
  const totalTime = timeTakenPerQuestion.reduce((a, b) => a + b, 0);
  document.getElementById("time-taken").textContent = totalTime;

  let reviewHTML = "";
  questions.forEach((q, i) => {
    const ua = userAnswers[i];
    const wrongClass = ua !== q.answer ? "wrong-answer" : "";
    reviewHTML += `
      <div class="answer-review">
        <b>प्रश्न ${i + 1}:</b> ${q.q}<br>
        आपका उत्तर: <span class="${wrongClass}">${ua !== null ? ua : "❌ कोई उत्तर नहीं"}</span><br>
        सही उत्तर: <span class="correct">${q.answer}</span><br>
        समय: ${timeTakenPerQuestion[i]} सेकंड<br>
        <i>${q.explanation.replace(/\n/g, '<br>')}</i>
      </div>
    `;
  });
  document.getElementById("answer-details").innerHTML = reviewHTML;
}

// ENTER key से अगले input पर cursor
setTimeout(() => {
  const inputs = document.querySelectorAll("input, textarea");
  inputs.forEach((el, i, arr) => {
    el.addEventListener("keypress", function (e) {
      if (e.key === "Enter") {
        if (el.tagName === "TEXTAREA") return;
        e.preventDefault();
        const next = arr[i + 1];
        if (next) next.focus();
      }
    });
  });
}, 1000);
